# Customer-Support Escalation Matrix

Routine questions about policy, order tracking, and standard return eligibility are handled by the first-level support workflow. Cases involving a delayed shipment beyond the stated delivery window, a payment deduction without an order, repeated failed pickups, or a disputed refund should be escalated to the specialist support queue. Suspected fraud, account compromise, or exposure of payment credentials requires immediate escalation and the customer should be advised not to share passwords, PINs, CVVs, or one-time passcodes.
