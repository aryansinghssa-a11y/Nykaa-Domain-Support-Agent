# International-Shipping Restrictions

This capstone's simulated store supports domestic delivery only and does not offer direct international shipping. Orders must use a supported domestic delivery address, and international forwarding addresses are not accepted in this project scenario. Customers outside the supported delivery area should not be promised shipment or customs handling by the support agent.
