# Damaged-Item Claim Process

A customer who receives a damaged, defective, or incorrect item should raise a claim within 48 hours of delivery under this synthetic project rule. The customer should provide the order ID and clear photographs showing the issue and the item packaging, while avoiding photographs that expose payment-card details or other sensitive information. Support reviews the evidence and communicates whether a replacement, return, or refund is appropriate under the applicable project policy.
