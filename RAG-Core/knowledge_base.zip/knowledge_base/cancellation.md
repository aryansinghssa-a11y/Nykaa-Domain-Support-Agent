# Order-Cancellation Policy

A customer may request cancellation while an order is still in the Placed status and has not entered shipment processing. Once an order is Shipped, cancellation through the standard workflow is unavailable and the customer must follow the applicable return process after delivery. A cancellation request is not confirmed until the order record or support system shows that the status has changed to Cancelled.
