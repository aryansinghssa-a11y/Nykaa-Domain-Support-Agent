# Warranty Terms by Category

In this simulated policy, Electronics products may carry a manufacturer warranty whose duration and coverage depend on the individual product listing and warranty card. Apparel, Footwear, Beauty, and most Home products do not receive a general manufacturer warranty under this project rule, although damaged or incorrect-item claims may still be reviewed separately. Customers should retain the invoice and warranty documentation and contact the manufacturer or support channel specified for the product.
