# Delivery Service-Level Agreements

For this synthetic project, standard domestic orders have an estimated delivery window of 3–7 business days from shipment confirmation. Remote delivery locations may require up to 10 business days, and the estimate can change because of weather, operational disruption, or courier constraints. The customer should use the order-tracking status as the latest available shipment update and contact support if the order remains unchanged beyond the estimated window.
