# Loyalty-Points Redemption Policy

For this synthetic project, eligible loyalty points may be applied at checkout when the customer is signed in and the order meets the minimum redemption conditions shown in the account. Points cannot be exchanged for cash or transferred to another customer account. If points are missing after an eligible purchase or redemption, the customer should contact support with the order ID and account details, without sharing passwords or one-time passcodes.
