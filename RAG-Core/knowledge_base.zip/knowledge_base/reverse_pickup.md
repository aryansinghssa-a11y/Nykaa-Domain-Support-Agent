# Reverse-Pickup Eligibility

A reverse pickup may be arranged for an order only after the return request has been approved and the item meets the applicable category return conditions. The item should be packed securely with its accessories, tags, and original packaging wherever applicable. If the pickup attempt fails, the customer should contact support to confirm the pickup address and arrange another attempt.
