# Payment-Failure and Retry Policy

If a payment attempt fails, the customer should first check whether the bank or payment provider has deducted the amount before attempting another payment. If the amount was deducted but the order was not created, the transaction should be checked against the payment provider's confirmation and the project support process. Customers should avoid repeated rapid payment attempts and should never share their full card number, PIN, CVV, or one-time passcode with support.
