# Cash-on-Delivery (COD) Refund Timelines

For this simulated support environment, an approved COD refund is issued through the bank-account or UPI details collected during the refund process. The expected processing time is 5–7 business days after the returned item passes the required inspection. If the refund has not arrived after 7 business days, the customer should contact support with the order ID and refund reference, if available.
