# Size-Exchange Policy

For this simulated policy, size exchange requests are available for eligible Apparel and Footwear items within 7 calendar days of delivery, subject to stock availability in the required size. The item must be unused, unwashed, undamaged, and returned with its original tags and packaging. If the requested size is unavailable, the customer may be offered the applicable return process instead of an exchange.
